﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace playMP3
{
    public partial class Form1 : Form
    {
        [DllImport("winmm.dll")]
        public static extern long mciSendString(string strCommand, StringBuilder strReturn, int strLen, IntPtr handle);
        private long Len;
        private bool open = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Mp3 Files|*.mp3";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (open)
                {
                    timer1.Enabled = false;
                    mciSendString("close media", null, 0, IntPtr.Zero);
                }

                textBox1.Text = dlg.FileName;
                playMP3(dlg.FileName);
            }
        }

        private void playMP3(string path)
        {
            string commandString = "open \"" + path + "\" type mpegvideo alias media";
            long Error = mciSendString(commandString, null, 0, IntPtr.Zero);
            StringBuilder strReturn = new StringBuilder(128);
            mciSendString("status media length", strReturn, 128, IntPtr.Zero);
            
            Len = Convert.ToInt32(strReturn.ToString());
            timer1.Enabled = true;
            label1.Text = "음악파일의 총밀리세컨드: " + Len;
            open = true;

            commandString = "seek media to 0";
            mciSendString(commandString, null, 0, IntPtr.Zero);
            commandString = "Play media notify";
            mciSendString(commandString, null, 0, IntPtr.Zero);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {            
            string commandString = "status media position";
            StringBuilder strReturn = new StringBuilder(128);
            mciSendString(commandString, strReturn, 128, IntPtr.Zero);

            label2.Text = "현재재생부분 밀리세컨드: " + strReturn;
            label3.Text = "음악 진행률: " + Convert.ToInt32(strReturn.ToString()) * 100 / Len + "% 재생중";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(textBox2.Text) >= 0 && Convert.ToInt32(textBox2.Text) <= 1000)
                mciSendString("setaudio media volume to " + textBox2.Text, null, 0, IntPtr.Zero);
            else
                MessageBox.Show("볼륨크기가 올바르지 않습니다! (0~1000)");
        }
    }
}
